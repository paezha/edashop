### FIRST INSTALL THE openrouteservice-r PACKAGE USING DEVTOOLS OR REMOTES ###

#install.packages("devtools")
#devtools::install_github("GIScience/openrouteservice-r")

#install.packages("remotes")
#remotes::install_github("GIScience/openrouteservice-r")

library(openrouteservice)

ors_api_key("INSERT YOUR KEY HERE")  #insert your key (token) requested at the openrouteservice.org

# Import the .csv file
position_input <- read.csv("coordinates_input.csv", sep=",", header = TRUE, stringsAsFactors = FALSE)

# Create a list of vectors. Each vector contains the geographic coordinates of each geographic location provided in the .csv file.
geo_pos<- as.list(as.data.frame(t(position_input[2:3])))

# Remove the names that were automatic generated for each vector, thus obtaining the list of geographic coordinates in the correct format for the distance matrix calculation.
geo_pos<- unname(geo_pos)

# ors_matrix is a function of the openrouteservice package. It creates the matrices with the travel duration and distances between each geographic location. 
res <- ors_matrix(geo_pos, metrics = c("duration", "distance"), units = "km")

# Store the obtained distance matrix in the object dist
dist <- res$distance

# Store the obtained travel duration matrix in the object ttime (the default travel duration is given in minutes, so we divided it by 3600 to obtain the travel duration in hours)
ttime <- res$durations / 3600

# Use the name of each geographic location to rename the rows and columns of the obtained distance matrix accordingly.
row.names(dist)<- position_input$NAME 
colnames(dist) <- position_input$NAME

# Use the name of each geographic location to rename the rows and columns of the obtained travel duration matrix accordingly.
row.names(ttime)<- position_input$NAME 
colnames(ttime) <- position_input$NAME

# Generate the .csv file with the distance matrix
write.csv(dist, file = "dist_output.csv")

# Generate the .csv file with the travel duration matrix
write.csv(ttime, file = "ttime_output.csv")

